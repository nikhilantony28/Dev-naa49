
int MAX11300(void);
